function say(){
	window.alert("This is Virus Cannot be Resolved");
	document.getElementById("demo").innerHTML=say();
	
}