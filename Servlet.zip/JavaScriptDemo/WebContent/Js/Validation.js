function validateLoginForm(){
	if(LoginForm.UserName.value==""){
		alert("Enter UserName")
		return false;
		
	}
	else if(LoginForm.Password.value==""){
		alert("Enter Password")
		return false;
	}
}
function validatePassword(){
	if(changepassword.password.value.length>=6){
		if(changepassword.password.value.search(/[0-9]/)!=-1&&
				changepassword.password.value.search(/[A-Z]/)!=-1&&
				changepassword.password.value.search(/[!@#$%^&*()_+.,<>:;"']/)!=-1){
			return true;
		}
		else{
			alert("Password must contain 1 UpperCase Letter and 1 Special Character");
			return false;
		}
	}
	else{
		alert("Minimum 6 characters needed ")
	return false;
	}
}

function checkSame(){
	if(changepassword.password.value==changepassword.Confirmpassword.value){
		alert("Password Changed");
		return true;
	}
		else {
			alert("Password and Confirm Password Did not match");
		return false;
		}
	
}